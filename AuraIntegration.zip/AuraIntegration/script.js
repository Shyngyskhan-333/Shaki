const TelegramBot = require('node-telegram-bot-api');
const Groq = require('groq-sdk');

// Configuration
const token = '8498388314:AAFIL5KbCTLLpImSrpASMLY9ORcfDCXo6Gk';
const groq = new Groq({ apiKey: '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' });
const bot = new TelegramBot(token, { polling: true });

// Store conversation history per chat (limit to last 10 messages)
const conversationHistory = new Map();
const MAX_HISTORY = 10;

console.log("Aura Mediator is live...");

bot.on('message', async (msg) => {
    // Only process text messages and ignore the bot's own messages
    if (!msg.text || msg.from.is_bot) return;

    const chatId = msg.chat.id;

    try {
        // Get or initialize conversation history for this chat
        if (!conversationHistory.has(chatId)) {
            conversationHistory.set(chatId, []);
        }
        const history = conversationHistory.get(chatId);

        // Build messages array with context
        const messages = [
            {
                role: "system",
                content: `You are Aura, a conflict mediator analyzing messages for toxic or hostile communication patterns.

IMPORTANT: Most normal, friendly, or neutral messages should be marked as NOT conflict (is_conflict: false).

Only mark as conflict (is_conflict: true) if the message contains:
- Insults, name-calling, or personal attacks
- Aggressive or threatening language
- Passive-aggressive remarks or sarcasm meant to hurt
- Dismissive or condescending tone
- Blaming, shaming, or guilt-tripping
- Yelling (excessive caps) or hostile punctuation

NEUTRAL messages (is_conflict: false) include:
- Greetings, casual conversation, small talk
- Questions, requests, or information sharing
- Positive or supportive statements
- Factual statements without hostile tone
- Expressions of personal feelings without blaming others

Response format - return a JSON object:
- If conflict detected: { "is_conflict": true, "subtext": "underlying emotion/intent", "score": 1-100, "suggestion": "empathic reframe" }
- If neutral/positive: { "is_conflict": false }

Be conservative - when in doubt, mark as NOT conflict.`
            },
            ...history,
            { role: "user", content: msg.text }
        ];

        // 1. Send the message to Groq for Aura Analysis
        const chatCompletion = await groq.chat.completions.create({
            messages: messages,
            model: "llama-3.3-70b-versatile",
            response_format: { type: "json_object" }
        });

        // Update conversation history
        history.push({ role: "user", content: msg.text });
        if (history.length > MAX_HISTORY) {
            history.shift(); // Remove oldest message
        }

        const aura = JSON.parse(chatCompletion.choices[0].message.content);

        // 2. Respond based on conflict level
        if (aura.is_conflict && aura.score > 60) {
            // High conflict - send warning
            const responseMessage =
                `⚠️ *Aura Tension Alert* (${aura.score}%)\n\n` +
                `*Subtext:* "${aura.subtext}"\n\n` +
                `*Try saying this instead:* \n"${aura.suggestion}"`;

            bot.sendMessage(chatId, responseMessage, {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.message_id
            });
        } else if (aura.is_conflict && aura.score > 0) {
            // Low to medium conflict - gentle suggestion
            const responseMessage =
                `💭 *Aura Notice* (${aura.score}%)\n\n` +
                `*Subtext:* "${aura.subtext}"\n\n` +
                `*Consider:* "${aura.suggestion}"`;

            bot.sendMessage(chatId, responseMessage, {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.message_id
            });
        } else {
            // Neutral message - just react with checkmark emoji
            bot.setMessageReaction(chatId, msg.message_id, [{ type: 'emoji', emoji: '✅' }])
                .catch(err => console.log('Reaction not supported in this chat type'));
        }
    } catch (error) {
        console.error("Aura Error:", error);
    }
});